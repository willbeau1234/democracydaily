// Simplified toaster component
export function Toaster() {
  // In a real implementation, this would render toasts
  // For our demo, we're using a simplified version that just returns null
  return null
}
